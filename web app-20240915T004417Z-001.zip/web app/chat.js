// const chatBox = document.getElementById('chatBox');
// const messageInput = document.getElementById('message');

// function sendMessage() {
//   const message = messageInput.value;
//   if (message.trim() === '') return;

//   // Display user's message
//   const userMessage = document.createElement('div');
//   userMessage.textContent = message;
//   userMessage.classList.add('message', 'user');
//   chatBox.appendChild(userMessage);

//   // Scroll to the bottom of the chat box
//   chatBox.scrollTop = chatBox.scrollHeight;

//   const formdata = new FormData();
//   formdata.append("question", message);

//   // Send the message to the API
//   fetch('http://127.0.0.1:5000/chat', {
//     method: 'POST',
//     body: formdata
//   })
//   .then(response => response.text())
//   .then(data => {
//     // Display the response from the API
//     const apiResponse = document.createElement('div');
//     apiResponse.textContent = data;
//     apiResponse.classList.add('message', 'api');
//     chatBox.appendChild(apiResponse);

//     // Scroll to the bottom of the chat box
//     chatBox.scrollTop = chatBox.scrollHeight;

//     // Clear the input field
//     messageInput.value = '';
//   })
//   .catch(error => {
//     console.error('Error:', error);
//     // Handle error, e.g., display an error message to the user
//   });
// }

const chatBox = document.getElementById('chatBox');
const messageInput = document.getElementById('message');

// Function to extract the option parameter from the URL
function getQueryParam(param) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(param);
}

// Get the 'option' from the query parameter
const selectedOption = getQueryParam('option');

function sendMessage() {
  const message = messageInput.value;
  if (message.trim() === '') return;

  // Display user's message
  const userMessage = document.createElement('div');
  userMessage.textContent = message;
  userMessage.classList.add('message', 'user');
  chatBox.appendChild(userMessage);

  // Scroll to the bottom of the chat box
  chatBox.scrollTop = chatBox.scrollHeight;

  const formdata = new FormData();
  formdata.append("question", message);
  
  // Add the selected option to the FormData
  formdata.append("option", selectedOption);

  // Send the message to the API
  fetch('http://127.0.0.1:5000/chat', {
    method: 'POST',
    body: formdata
  })
  .then(response => response.text())
  .then(data => {
    // Display the response from the API
    const apiResponse = document.createElement('div');
    apiResponse.textContent = data;
    apiResponse.classList.add('message', 'api');
    chatBox.appendChild(apiResponse);

    // Scroll to the bottom of the chat box
    chatBox.scrollTop = chatBox.scrollHeight;

    // Clear the input field
    messageInput.value = '';
  })
  .catch(error => {
    console.error('Error:', error);
    // Handle error, e.g., display an error message to the user
  });
}


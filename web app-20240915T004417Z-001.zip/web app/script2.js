// Function to fetch data from the API
function fetchData() {
    const apiUrl = 'http://localhost:5000/docs'; // Replace with your actual API endpoint

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            displayOptions(data);
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
}

// Function to display options as boxes
function displayOptions(data) {
    const container = document.querySelector('.options-container');

    data.forEach(item => {
        const optionBox = document.createElement('div');
        optionBox.className = 'option-box';
        optionBox.innerText = item.name;

        // Redirect to 'chat.html' with query parameter
        optionBox.addEventListener('click', () => {
            window.location.href = `chat.html?option=${encodeURIComponent(item.name)}`;
        });

        container.appendChild(optionBox);
    });
}

// Call fetchData when the page loads
window.onload = fetchData;
